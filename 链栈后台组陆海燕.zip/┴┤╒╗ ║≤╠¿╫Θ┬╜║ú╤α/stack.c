#define ERROR -1
#define TRUE  1
#define OK    1
#define FALSE 0
typedef int ElemType;
typedef int Status;
//����ջ�Ľ��
typedef struct StackNode {
	ElemType data;
	struct StackNode* next;
}StackNode, *LinkStackPtr;
//
typedef struct LinkStack {
	LinkStackPtr top;   //ջ��ָ��
	int count;  //ջ��Ԫ�ظ���
}LinkStack, *PStack;

// ��ʽջ��������
int initStack(PStack *s);
int isEmpty(LinkStack *s);
ElemType getTop(LinkStack *s);
int clear(LinkStack *s);
int destroyStack(LinkStack *s);
int  stackLengh(LinkStack *s);
int Push(PStack s, ElemType e);
ElemType Pop(PStack s);