#include <stdio.h>
#include <stdlib.h>
#include "stack.c"

/**����һ����ջ,**/
int initStack(PStack *s) {
	(*s) = (PStack)malloc(sizeof(LinkStack));
	if (NULL != *s) {
		(*s)->top = NULL;
		(*s)->count = 0;
		return OK;
	}
	return ERROR;
}

/**�ж��Ƿ�Ϊ��ջ**/
int  isEmpty(LinkStack *s) {
	if (s->top != NULL) return TRUE;
	return FALSE;
}

/**��ջ������Ԫ��**/
int Push(PStack s, ElemType e) {
	LinkStackPtr PNew = (LinkStackPtr)malloc(sizeof(StackNode));
	if (NULL == PNew) return ERROR;
	PNew->data = e;
	PNew->next = s->top;
	s->top = PNew;
	s->count++;
	return OK;
}

/**����ջ��Ԫ��**/
ElemType getTop(LinkStack *s) {
	if (NULL != s->top)
		return s->top->data;
	return ERROR;
}

/**ɾ��������ӵ�������ظ���**/
ElemType Pop(PStack s) {
	if (isEmpty(s) == 1) {
		LinkStackPtr p = s->top;
		ElemType data = p->data;
		s->top = p->next;
		s->count--;
		free(p);
		return data;
	}
	return FALSE;
}

/**�����ջ**/
int  clear(LinkStack *s) {
	LinkStackPtr p = s->top, q;
	while (isEmpty(s)) {
		s->top = p->next;
		q = p;
		p = s->top;
		free(q);
	}
	s->count = 0;
	return OK;
}

/**������ջ**/
int  destroyStack(LinkStack *s) {
	LinkStackPtr p = s->top;
	while (isEmpty(s)) {
		s->top = p->next;
		free(p);
		p = s->top;
	}
	free(s->top);
	return OK;
}

/**������ջ����**/
int  stackLengh(LinkStack *s) {
	if (isEmpty(s) == 0) return FALSE;
	return s->count;
}