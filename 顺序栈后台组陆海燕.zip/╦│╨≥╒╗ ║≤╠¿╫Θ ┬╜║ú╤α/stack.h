#define ERROR -1
#define TRUE  1
#define OK    1
#define FALSE 0
typedef int ElemType;
typedef int Status;
//����ջ�Ľ��
typedef struct StackNode{
    ElemType data;
    struct StackNode* next;
}StackNode, *LinkStackPtr;
//
 typedef struct LinkStack{
    LinkStackPtr top;   //ջ��ָ��
    int count;  //ջ��Ԫ�ظ���
 }LinkStack, *PStack;

// ��ʽջ��������
int initStack(PStack *s);
int isEmpty(LinkStack *s);
ElemType getTop(LinkStack *s);
int clear(LinkStack *s);
int destroyStack(LinkStack *s);
int  stackLengh(LinkStack *s);
int Push(PStack s, ElemType e);
ElemType Pop(PStack s);

/**����һ����ջ,**/
int initStack(PStack *s) {
	*s = (LinkStackPtr)malloc(sizeof(StackNode));
	if (NULL != *s) {
		(*s)->top = NULL;
		(*s)->count = 0;
		return OK;
	}
	return ERROR;
}

/**�ж��Ƿ�Ϊ��ջ**/
int  isEmpty(LinkStack *s) {
	if (s->top != NULL) return TRUE;
	return FALSE;
}

/**��ջ������Ԫ��**/
int Push(PStack s, ElemType e) {
	LinkStackPtr PNew = (LinkStackPtr)malloc(sizeof(StackNode));
	if (NULL == PNew) return ERROR;
	PNew->data = e;
	PNew->next = s->top;
	s->top = PNew;
	s->count++;
	return OK;
}

/**����ջ��Ԫ��**/
ElemType getTop(LinkStack *s) {
	if (NULL != s->top)
		return s->top->data;
	return ERROR;
}

/**ɾ��������ӵ�������ظ���**/
ElemType Pop(PStack s) {
	if (isEmpty(s) == 1) {
		LinkStackPtr p = s->top;
		ElemType data = p->data;
		s->top = p->next;
		s->count--;
		free(p);
		return data;
	}
	return FALSE;
}

/**�����ջ**/
int  clear(LinkStack *s) {
	LinkStackPtr p = s->top, q;
	while (isEmpty(s)) {
		s->top = p->next;
		q = p;
		p = s->top;
		free(q);
	}
	s->count=0;
	return OK;
}

/**������ջ**/
int  destroyStack(LinkStack *s) {
	LinkStackPtr p = s->top;
	while (isEmpty(s)) {
		s->top = p->next;
		free(p);
		p = s->top;
	}
	free(s->top);
	return OK;
}

/**������ջ����**/
int  stackLengh(LinkStack *s) {
	if (isEmpty(s) == 0) return FALSE;
	return s->count;
}