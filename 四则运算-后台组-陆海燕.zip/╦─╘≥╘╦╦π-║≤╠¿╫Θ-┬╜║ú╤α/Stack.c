#include "expression.h"


/**����һ����ջ,**/
Status initStack(LinkStackPtr s) {
	if (NULL != s) {
		s->top = NULL;
		s->count = 0;
		return TRUE;
	}
	return FALSE;
}

/**�ж��Ƿ�Ϊ��ջ**/
Status  isEmpty(LinkStackPtr s) {
	if (s->top != NULL) return TRUE;
	return FALSE;
}

/**��ջ������Ԫ��**/
Status Push(LinkStackPtr s, ElemType e) {
	StackNodePtr PNew = (StackNodePtr)malloc(sizeof(StackNode));
	if (NULL == PNew) return  ERROR;
	PNew->data = e;
	PNew->next = s->top;
	s->top = PNew;
	s->count++;
	return TRUE;
}

/**����ջ��Ԫ��**/
ElemType getTop(LinkStackPtr s) {
	if (NULL != s->top)
		return s->top->data;
	return ERROR;
}

/**ɾ��������ӵ�������ظ���**/
ElemType Pop(LinkStackPtr s, ElemType*e ) {
	if (isEmpty(s) == TRUE) {
		StackNodePtr p = s->top;
		*e = p->data;
		s->top = p->next;
		s->count--;
		free(p);
		return TRUE;
	}
	return FALSE;
}

/**�����ջ**/
Status  clear(LinkStackPtr s) {
	StackNodePtr p = s->top, q;
	while (isEmpty(s)) {
		s->top = p->next;
		q = p;
		p = s->top;
		free(q);
	}
	s->count = 0;
	return TRUE;
}

/**������ջ**/
Status  destroyStack(LinkStackPtr s) {
	StackNodePtr p = s->top;
	while (isEmpty(s) != FALSE) {
		s->top = p->next;
		free(p);
		p = s->top;
	}
	free(s->top);
	return TRUE;
}
Status OnlyOne(LinkStackPtr s) {
	//printf("%d\n", s->count);
	if (s->count == 1) return s->top->data;
	return FALSE;
}
