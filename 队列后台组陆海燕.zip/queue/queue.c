#include "queue.h"

//��ʼ��ָ�����
Status InitQueue(Queue *Q) {
	Q->front = Q->rear = (QueuePtr)malloc(LEN);
	if (!Q->front) return FALSE;
	Q->front->next = NULL;
	Q->count = 0;
	Q->front->queueOutput = NULL;
	return OK;
}

Status DestoryQueue(Queue *Q) {
	while (NULL != Q->front) {
		Q->rear = Q->front->next;
		free(Q->front);
		Q->front = Q->rear;
	}
	return OK;
}

Status IsEmptyQueue(Queue *Q) {
	if (Q->front == Q->rear)   return TRUE;
	return FALSE;
}

Status GetHeadQueue(Queue *Q) {
	if (TRUE == IsEmptyQueue(Q))    return FALSE;
	(Q->front->next->queueOutput)(Q->front->next);  //�����������
	return OK;
}

int LengthQueue(Queue *Q) {
	if (Q->front == Q->rear) return FALSE;
	return Q->count;
}

Status EnQueue(Queue *Q, void *data, int c) {
	QueuePtr p = (QueuePtr)malloc(LEN);
	if (NULL == p)   return OVERFLOW;
	//printf("???");
	//printf("EEE%d\n", *(int*)(data));
	p->data = data;
	p->next = NULL;
	Q->rear->next = p;
	Q->rear = p;
	Q->count++;
	//printf("%d\n",Q->count);
	switch (c) {
	case 6:
		p->queueOutput = stringOutput; break;
	case 7:
		p->queueOutput = intOutput; break;
	case 8:
		p->queueOutput = doubleOutput; break;
	case 9:
		p->queueOutput = charOutput; break;
	}
	return OK;
}

Status DeQueue(Queue *Q) {
	if (Q->front == Q->rear)    return FALSE;
	QueuePtr p = Q->front->next;
	Q->front->next = p->next;
	if (p == Q->rear)
		Q->rear = Q->front;
	free(p);
	Q->count--;
	return OK;
}

Status ClearQueue(Queue *Q) {
	if (Q->front == Q->rear)  return FALSE;
	QueuePtr p = Q->front->next;
	while (NULL != p) {
		Q->front->next = p->next;
		if (p == Q->rear)
			Q->rear = Q->front;
		free(p);
	}
	return OK;
}

Status Output(Queue *Q) {
	//���в�Ϊ��
	int line = 1;
	if (Q->front == Q->rear) {
		return FALSE;
	}
	QueuePtr p = Q->front->next;
	while (p) {
		if (line % 5 == 0)  printf("\n");
		(p->queueOutput)(p);
		p = p->next;
		line++;
	}
	return OK;
}



//δָ������ʱ��Ĭ���������
/*void QueueOutput(Node *p) {
	if (p->queueOutput != NULL) return;
	int n;
	printf("��ָ�������������ͣ�");
	printf("\n�ַ�����\t6");
	printf("\n�������ݣ�\t7");
	printf("\n���������ݣ�\t8");
	printf("\n�ַ������ݣ�\t9\n\n");

	while (1)
	{
		scanf("%d", &n);
		if (n >= 6 && n <= 9) break;
	}

	switch (n)
	{
	case 6:
		p->queueOutput = stringOutput; break;
	case 7:
		p->queueOutput = intOutput; break;
	case 8:
		p->queueOutput = doubleOutput; break;
	case 9:
		p->queueOutput = charOutput; break;
	}
}*/



//����ַ����������ݵĺ���
void stringOutput(Node *p) {
	//QueuePtr p = Q->front -> next ;
	//while(NULL != p){
	printf("%s\t", (char*)(p->data));
	//p = p -> next;
	//}
	printf("\n");
}

//����������ݵĺ���
void intOutput(Node *p) {
	//QueuePtr p = Q->front -> next ;
	//while(NULL != p){
	printf("%d\t", *(int*)(p->data));
	// p = p -> next;
	//}
	printf("\n");
}

//������������ݵĺ���
void doubleOutput(Node *p) {
	// QueuePtr p = Q->front -> next ;
	//while(NULL != p){
	printf("%f\t", *(float*)(p->data));
	// p = p -> next;
	// }
	printf("\n");
}

//����ַ������ݵĺ���
void charOutput(Node *p) {
	// QueuePtr p = Q->front -> next ;
	// while(NULL != p){
	printf("%c\t", *(char*)(p->data));
	// p = p -> next;
	//}
	printf("\n");
}
